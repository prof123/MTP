#ifndef NOX_CONFIG_HH
#define NOX_CONFIG_HH

const char* pkgdatadir    = PKGDATADIR;
const char* pkgsysconfdir = PKGSYSCONFDIR;
const char* pkglibdir     = PKGLIBDIR;
const char* version       = NOX_VERSION;
const int   buildnr       = BUILDNR;

#endif  // -- NOX_CONFIG_HH
